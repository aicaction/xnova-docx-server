# xNova DOCX Generator

Micro-servicio Flask que convierte texto/Markdown en archivos .docx formateados.

## Endpoint

POST /generate
Content-Type: application/json

{
  "content": "## Título\nContenido en markdown...",
  "title": "BusinessCase_xNova_2024-01-15"
}

Devuelve el archivo .docx binario.

## Deploy en Railway (gratis)

1. Sube esta carpeta a un repo de GitHub
2. Ve a railway.app → New Project → Deploy from GitHub
3. Selecciona el repo → Railway detecta automáticamente Python
4. Copia la URL pública que te genera (ej: https://xnova-docx.up.railway.app)
5. Usa esa URL en Make: https://tu-url.up.railway.app/generate
